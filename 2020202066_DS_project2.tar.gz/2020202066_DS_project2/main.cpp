#include "Manager.h"
using namespace std;

int main() {
	Manager manager(3); //value is order of bptree 
	manager.run("command.txt");
	return 0;
}

